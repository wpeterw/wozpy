#wozpy

[![codecov](https://codecov.io/gh/wpeterw/wozpy/graph/badge.svg?token=RZRGLN432W)](https://codecov.io/gh/wpeterw/wozpy)
[![Coverage](https://snyk.io/test/github/wpeterw/wozpy/badge.svg)](https://snyk.io/test/github/wpeterw/wozpy)
[![Quality Gate Status](https://sonar.randombits.nl/api/project_badges/measure?project=wozpy&metric=alert_status&token=sqb_2339051b02256716cd52bed1a33d1065c76d0fef)](https://sonar.randombits.nl/dashboard?id=wozpy)

# Pythonpackage to get data from wozwaardeloket.nl


